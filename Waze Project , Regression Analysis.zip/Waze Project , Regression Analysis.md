# Waze Project

The aim of this project is to build a binomial logistic regression model to predict user churn for Waze, leveraging exploratory data analysis (EDA) to identify key variables and relationships. The purpose is to provide actionable insights and recommendations to Waze leadership by evaluating the model's performance and identifying factors influencing user retention. The project demonstrates skills in data analysis, model building, and interpretation of results to address business challenges.

### Imports libraries and data loading


```python
# Packages 
import pandas as pd
import numpy as np
from scipy import stats
# Packages for visualization
import matplotlib.pyplot as plt
import seaborn as sns
# Packages for Logistic Regression & Confusion Matrix
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score,precision_score, \
recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
from sklearn.linear_model import LogisticRegression

import warnings
warnings.filterwarnings("ignore")

```

### Loading the dataset and EDA.



```python
df = pd.read_csv('waze_dataset.csv')

```


```python
# the shape and summary about the dataset
print(df.shape)
df.info()

```

    (14999, 13)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 14999 entries, 0 to 14998
    Data columns (total 13 columns):
     #   Column                   Non-Null Count  Dtype  
    ---  ------                   --------------  -----  
     0   ID                       14999 non-null  int64  
     1   label                    14299 non-null  object 
     2   sessions                 14999 non-null  int64  
     3   drives                   14999 non-null  int64  
     4   total_sessions           14999 non-null  float64
     5   n_days_after_onboarding  14999 non-null  int64  
     6   total_navigations_fav1   14999 non-null  int64  
     7   total_navigations_fav2   14999 non-null  int64  
     8   driven_km_drives         14999 non-null  float64
     9   duration_minutes_drives  14999 non-null  float64
     10  activity_days            14999 non-null  int64  
     11  driving_days             14999 non-null  int64  
     12  device                   14999 non-null  object 
    dtypes: float64(3), int64(8), object(2)
    memory usage: 1.5+ MB
    


```python
#checking for column heads
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>label</th>
      <th>sessions</th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>driving_days</th>
      <th>device</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>retained</td>
      <td>283</td>
      <td>226</td>
      <td>296.748273</td>
      <td>2276</td>
      <td>208</td>
      <td>0</td>
      <td>2628.845068</td>
      <td>1985.775061</td>
      <td>28</td>
      <td>19</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>retained</td>
      <td>133</td>
      <td>107</td>
      <td>326.896596</td>
      <td>1225</td>
      <td>19</td>
      <td>64</td>
      <td>13715.920550</td>
      <td>3160.472914</td>
      <td>13</td>
      <td>11</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>retained</td>
      <td>114</td>
      <td>95</td>
      <td>135.522926</td>
      <td>2651</td>
      <td>0</td>
      <td>0</td>
      <td>3059.148818</td>
      <td>1610.735904</td>
      <td>14</td>
      <td>8</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>retained</td>
      <td>49</td>
      <td>40</td>
      <td>67.589221</td>
      <td>15</td>
      <td>322</td>
      <td>7</td>
      <td>913.591123</td>
      <td>587.196542</td>
      <td>7</td>
      <td>3</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>retained</td>
      <td>84</td>
      <td>68</td>
      <td>168.247020</td>
      <td>1562</td>
      <td>166</td>
      <td>5</td>
      <td>3950.202008</td>
      <td>1219.555924</td>
      <td>27</td>
      <td>18</td>
      <td>Android</td>
    </tr>
  </tbody>
</table>
</div>




```python
#drop the ID column  
df = df.drop('ID', axis=1)

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>sessions</th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>driving_days</th>
      <th>device</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>retained</td>
      <td>283</td>
      <td>226</td>
      <td>296.748273</td>
      <td>2276</td>
      <td>208</td>
      <td>0</td>
      <td>2628.845068</td>
      <td>1985.775061</td>
      <td>28</td>
      <td>19</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>1</th>
      <td>retained</td>
      <td>133</td>
      <td>107</td>
      <td>326.896596</td>
      <td>1225</td>
      <td>19</td>
      <td>64</td>
      <td>13715.920550</td>
      <td>3160.472914</td>
      <td>13</td>
      <td>11</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>2</th>
      <td>retained</td>
      <td>114</td>
      <td>95</td>
      <td>135.522926</td>
      <td>2651</td>
      <td>0</td>
      <td>0</td>
      <td>3059.148818</td>
      <td>1610.735904</td>
      <td>14</td>
      <td>8</td>
      <td>Android</td>
    </tr>
    <tr>
      <th>3</th>
      <td>retained</td>
      <td>49</td>
      <td>40</td>
      <td>67.589221</td>
      <td>15</td>
      <td>322</td>
      <td>7</td>
      <td>913.591123</td>
      <td>587.196542</td>
      <td>7</td>
      <td>3</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>4</th>
      <td>retained</td>
      <td>84</td>
      <td>68</td>
      <td>168.247020</td>
      <td>1562</td>
      <td>166</td>
      <td>5</td>
      <td>3950.202008</td>
      <td>1219.555924</td>
      <td>27</td>
      <td>18</td>
      <td>Android</td>
    </tr>
  </tbody>
</table>
</div>




```python
# propostion of labels in the dataset
percent_df=df['label'].value_counts(normalize=True)*100
percent_df1 = percent_df.round(2).astype(str)+'%'
percent_df1
```




    label
    retained    82.26%
    churned     17.74%
    Name: proportion, dtype: object




```python
df["device"].unique()
```




    array(['Android', 'iPhone'], dtype=object)




```python
 df.describe().round()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sessions</th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>driving_days</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
      <td>14999.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>81.0</td>
      <td>67.0</td>
      <td>190.0</td>
      <td>1750.0</td>
      <td>122.0</td>
      <td>30.0</td>
      <td>4039.0</td>
      <td>1861.0</td>
      <td>16.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>81.0</td>
      <td>66.0</td>
      <td>136.0</td>
      <td>1009.0</td>
      <td>148.0</td>
      <td>45.0</td>
      <td>2502.0</td>
      <td>1447.0</td>
      <td>9.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>18.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>23.0</td>
      <td>20.0</td>
      <td>91.0</td>
      <td>878.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>2213.0</td>
      <td>836.0</td>
      <td>8.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>56.0</td>
      <td>48.0</td>
      <td>160.0</td>
      <td>1741.0</td>
      <td>71.0</td>
      <td>9.0</td>
      <td>3494.0</td>
      <td>1478.0</td>
      <td>16.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>112.0</td>
      <td>93.0</td>
      <td>254.0</td>
      <td>2624.0</td>
      <td>178.0</td>
      <td>43.0</td>
      <td>5290.0</td>
      <td>2464.0</td>
      <td>23.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>743.0</td>
      <td>596.0</td>
      <td>1216.0</td>
      <td>3500.0</td>
      <td>1236.0</td>
      <td>415.0</td>
      <td>21183.0</td>
      <td>15852.0</td>
      <td>31.0</td>
      <td>30.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# propostion of device in the dataset
percent1_df=df['device'].value_counts(normalize=True)*100
percent1_df = percent1_df.round(2).astype(str)+'%'
percent1_df
```




    device
    iPhone     64.48%
    Android    35.52%
    Name: proportion, dtype: object




```python
 # average number of drives for each device in km.
df.groupby('device')['drives'].mean().round(2)
```




    device
    Android    66.23
    iPhone     67.86
    Name: drives, dtype: float64




```python
# map_dictionary is created
map_dictionary = {'Android': 2, 'iPhone': 1}
 # new device_type column
df['device_type'] = df['device']
 # Map the new column to the dictionary
df['device_type'] = df['device_type'].map(map_dictionary)
df['device_type'].head()
```




    0    2
    1    1
    2    2
    3    1
    4    2
    Name: device_type, dtype: int64




```python
df["device"].head()
```




    0    Android
    1     iPhone
    2    Android
    3     iPhone
    4    Android
    Name: device, dtype: object



### Hypotheses testing
*H0: There is no difference in average number of drives between drivers who use iPhone devices and drivers who use Androids.*


```python
#check if there are statistically differences between avearage use of devices
 #  Isolate the `drives` column for Android and iphone users.
Android = df[df['device_type'] == 2]['drives']
    
iPhone = df[df['device_type'] == 1]['drives']

#  t-test is performed to check the pvalue
stats.ttest_ind(a=iPhone, b=Android, equal_var=False)
```




    TtestResult(statistic=1.463523206885235, pvalue=0.143351972680206, df=11345.066049381952)



*Since the p-value is larger than  5%, we fail to reject the null hypothesis. You conclude that there is not a statistically significant difference in the average number of drives between drivers who use iPhones and drivers who use Androids. This implies that Android and iphone users have similar drives.*

#### Adding more features to understand the scenario.



```python
# km_per_driving_day column
df['km_per_driving_day'] = df['driven_km_drives'] / df['driving_days']

df['km_per_driving_day'].describe()

```




    count    1.499900e+04
    mean              inf
    std               NaN
    min      3.022063e+00
    25%      1.672804e+02
    50%      3.231459e+02
    75%      7.579257e+02
    max               inf
    Name: km_per_driving_day, dtype: float64




```python
 #  change infinite values to zero
df.loc[df['km_per_driving_day']==np.inf, 'km_per_driving_day'] = 0

# Confirm that it worked
df['km_per_driving_day'].describe()

```




    count    14999.000000
    mean       578.963113
    std       1030.094384
    min          0.000000
    25%        136.238895
    50%        272.889272
    75%        558.686918
    max      15420.234110
    Name: km_per_driving_day, dtype: float64




```python
# Create professional_driver column, 1 indicate a professional driver and 0 indicate a non professional driver.
df['professional_driver'] = np.where((df['drives'] >= 60) & (df['driving_days']>= 15), 1, 0)
df['professional_driver']
```




    0        1
    1        0
    2        0
    3        0
    4        1
            ..
    14994    0
    14995    0
    14996    1
    14997    0
    14998    0
    Name: professional_driver, Length: 14999, dtype: int32




```python
#  Check count of professionals and non-professionals
print(df['professional_driver'].value_counts())

#  Check in-class churn rate
df.groupby(['professional_driver'])['label'].value_counts(normalize=True).mul(100).round(2).astype('str')+'%'

```

    professional_driver
    0    12405
    1     2594
    Name: count, dtype: int64
    




    professional_driver  label   
    0                    retained    80.12%
                         churned     19.88%
    1                    retained    92.44%
                         churned      7.56%
    Name: proportion, dtype: object



The churn rate for professional drivers is 7.56%, while the churn rate for non-professionals is 19.88%.


```python
#check if there are null values in the label variable column and futher drop rows with missing data in `label` colum
print(df.info())
print()


```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 14999 entries, 0 to 14998
    Data columns (total 15 columns):
     #   Column                   Non-Null Count  Dtype  
    ---  ------                   --------------  -----  
     0   label                    14299 non-null  object 
     1   sessions                 14999 non-null  int64  
     2   drives                   14999 non-null  int64  
     3   total_sessions           14999 non-null  float64
     4   n_days_after_onboarding  14999 non-null  int64  
     5   total_navigations_fav1   14999 non-null  int64  
     6   total_navigations_fav2   14999 non-null  int64  
     7   driven_km_drives         14999 non-null  float64
     8   duration_minutes_drives  14999 non-null  float64
     9   activity_days            14999 non-null  int64  
     10  driving_days             14999 non-null  int64  
     11  device                   14999 non-null  object 
     12  device_type              14999 non-null  int64  
     13  km_per_driving_day       14999 non-null  float64
     14  professional_driver      14999 non-null  int32  
    dtypes: float64(4), int32(1), int64(8), object(2)
    memory usage: 1.7+ MB
    None
    
    


```python
df = df.dropna(subset=['label'])
```


```python
 # Impute outliers, using the 96th percentile for the columns below
for column in ['sessions', 'drives', 'total_sessions', 'total_navigations_fav1',
               'total_navigations_fav2','driven_km_drives','duration_minutes_drives']:
    threshold = df[column].quantile(0.95)
    df.loc[df[column] > threshold, column] = threshold
```


```python
df.describe().round()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sessions</th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>driving_days</th>
      <th>device_type</th>
      <th>km_per_driving_day</th>
      <th>professional_driver</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
      <td>14299.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>77.0</td>
      <td>64.0</td>
      <td>184.0</td>
      <td>1752.0</td>
      <td>115.0</td>
      <td>27.0</td>
      <td>3945.0</td>
      <td>1793.0</td>
      <td>16.0</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>582.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>67.0</td>
      <td>55.0</td>
      <td>119.0</td>
      <td>1009.0</td>
      <td>124.0</td>
      <td>37.0</td>
      <td>2218.0</td>
      <td>1224.0</td>
      <td>9.0</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>1038.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>18.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>23.0</td>
      <td>20.0</td>
      <td>90.0</td>
      <td>878.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>2217.0</td>
      <td>840.0</td>
      <td>8.0</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>136.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>56.0</td>
      <td>48.0</td>
      <td>159.0</td>
      <td>1749.0</td>
      <td>71.0</td>
      <td>9.0</td>
      <td>3497.0</td>
      <td>1479.0</td>
      <td>16.0</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>273.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>111.0</td>
      <td>93.0</td>
      <td>254.0</td>
      <td>2628.0</td>
      <td>178.0</td>
      <td>43.0</td>
      <td>5300.0</td>
      <td>2467.0</td>
      <td>23.0</td>
      <td>19.0</td>
      <td>2.0</td>
      <td>558.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>243.0</td>
      <td>200.0</td>
      <td>455.0</td>
      <td>3500.0</td>
      <td>422.0</td>
      <td>124.0</td>
      <td>8899.0</td>
      <td>4668.0</td>
      <td>31.0</td>
      <td>30.0</td>
      <td>2.0</td>
      <td>15420.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
 # binary label2 column, assign retained users to 0 and churn users to 1
df['label2'] = np.where(df['label']=='churned', 1, 0)
df[['label', 'label2']].head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>label2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>retained</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>retained</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>retained</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>retained</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>retained</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Check the correlation among predictor variables
df.select_dtypes(include=[np.number]).corr(method='pearson')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sessions</th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>driving_days</th>
      <th>device_type</th>
      <th>km_per_driving_day</th>
      <th>professional_driver</th>
      <th>label2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>sessions</th>
      <td>1.000000</td>
      <td>0.996942</td>
      <td>0.597189</td>
      <td>0.007101</td>
      <td>0.001858</td>
      <td>0.008536</td>
      <td>0.002996</td>
      <td>-0.004545</td>
      <td>0.025113</td>
      <td>0.020294</td>
      <td>-0.012704</td>
      <td>-0.011569</td>
      <td>0.443654</td>
      <td>0.034911</td>
    </tr>
    <tr>
      <th>drives</th>
      <td>0.996942</td>
      <td>1.000000</td>
      <td>0.595285</td>
      <td>0.006940</td>
      <td>0.001058</td>
      <td>0.009505</td>
      <td>0.003445</td>
      <td>-0.003889</td>
      <td>0.024357</td>
      <td>0.019608</td>
      <td>-0.011684</td>
      <td>-0.010989</td>
      <td>0.444425</td>
      <td>0.035865</td>
    </tr>
    <tr>
      <th>total_sessions</th>
      <td>0.597189</td>
      <td>0.595285</td>
      <td>1.000000</td>
      <td>0.006596</td>
      <td>0.000187</td>
      <td>0.010371</td>
      <td>0.001016</td>
      <td>-0.000338</td>
      <td>0.015755</td>
      <td>0.012953</td>
      <td>-0.012138</td>
      <td>-0.016167</td>
      <td>0.254433</td>
      <td>0.024568</td>
    </tr>
    <tr>
      <th>n_days_after_onboarding</th>
      <td>0.007101</td>
      <td>0.006940</td>
      <td>0.006596</td>
      <td>1.000000</td>
      <td>-0.002450</td>
      <td>-0.004968</td>
      <td>-0.004652</td>
      <td>-0.010167</td>
      <td>-0.009418</td>
      <td>-0.007321</td>
      <td>0.011299</td>
      <td>0.011764</td>
      <td>0.003770</td>
      <td>-0.129263</td>
    </tr>
    <tr>
      <th>total_navigations_fav1</th>
      <td>0.001858</td>
      <td>0.001058</td>
      <td>0.000187</td>
      <td>-0.002450</td>
      <td>1.000000</td>
      <td>0.002866</td>
      <td>-0.007368</td>
      <td>0.005646</td>
      <td>0.010902</td>
      <td>0.010419</td>
      <td>0.001316</td>
      <td>-0.000197</td>
      <td>-0.000224</td>
      <td>0.052322</td>
    </tr>
    <tr>
      <th>total_navigations_fav2</th>
      <td>0.008536</td>
      <td>0.009505</td>
      <td>0.010371</td>
      <td>-0.004968</td>
      <td>0.002866</td>
      <td>1.000000</td>
      <td>0.003559</td>
      <td>-0.003009</td>
      <td>-0.004425</td>
      <td>0.002000</td>
      <td>0.000275</td>
      <td>0.006751</td>
      <td>0.007126</td>
      <td>0.015032</td>
    </tr>
    <tr>
      <th>driven_km_drives</th>
      <td>0.002996</td>
      <td>0.003445</td>
      <td>0.001016</td>
      <td>-0.004652</td>
      <td>-0.007368</td>
      <td>0.003559</td>
      <td>1.000000</td>
      <td>0.690515</td>
      <td>-0.007441</td>
      <td>-0.009549</td>
      <td>0.002091</td>
      <td>0.344811</td>
      <td>-0.000904</td>
      <td>0.019767</td>
    </tr>
    <tr>
      <th>duration_minutes_drives</th>
      <td>-0.004545</td>
      <td>-0.003889</td>
      <td>-0.000338</td>
      <td>-0.010167</td>
      <td>0.005646</td>
      <td>-0.003009</td>
      <td>0.690515</td>
      <td>1.000000</td>
      <td>-0.007895</td>
      <td>-0.009425</td>
      <td>0.007709</td>
      <td>0.239627</td>
      <td>-0.012128</td>
      <td>0.040407</td>
    </tr>
    <tr>
      <th>activity_days</th>
      <td>0.025113</td>
      <td>0.024357</td>
      <td>0.015755</td>
      <td>-0.009418</td>
      <td>0.010902</td>
      <td>-0.004425</td>
      <td>-0.007441</td>
      <td>-0.007895</td>
      <td>1.000000</td>
      <td>0.947687</td>
      <td>0.010221</td>
      <td>-0.397433</td>
      <td>0.453825</td>
      <td>-0.303851</td>
    </tr>
    <tr>
      <th>driving_days</th>
      <td>0.020294</td>
      <td>0.019608</td>
      <td>0.012953</td>
      <td>-0.007321</td>
      <td>0.010419</td>
      <td>0.002000</td>
      <td>-0.009549</td>
      <td>-0.009425</td>
      <td>0.947687</td>
      <td>1.000000</td>
      <td>0.003859</td>
      <td>-0.407917</td>
      <td>0.469776</td>
      <td>-0.294259</td>
    </tr>
    <tr>
      <th>device_type</th>
      <td>-0.012704</td>
      <td>-0.011684</td>
      <td>-0.012138</td>
      <td>0.011299</td>
      <td>0.001316</td>
      <td>0.000275</td>
      <td>0.002091</td>
      <td>0.007709</td>
      <td>0.010221</td>
      <td>0.003859</td>
      <td>1.000000</td>
      <td>-0.002979</td>
      <td>-0.007274</td>
      <td>-0.003406</td>
    </tr>
    <tr>
      <th>km_per_driving_day</th>
      <td>-0.011569</td>
      <td>-0.010989</td>
      <td>-0.016167</td>
      <td>0.011764</td>
      <td>-0.000197</td>
      <td>0.006751</td>
      <td>0.344811</td>
      <td>0.239627</td>
      <td>-0.397433</td>
      <td>-0.407917</td>
      <td>-0.002979</td>
      <td>1.000000</td>
      <td>-0.165966</td>
      <td>0.148583</td>
    </tr>
    <tr>
      <th>professional_driver</th>
      <td>0.443654</td>
      <td>0.444425</td>
      <td>0.254433</td>
      <td>0.003770</td>
      <td>-0.000224</td>
      <td>0.007126</td>
      <td>-0.000904</td>
      <td>-0.012128</td>
      <td>0.453825</td>
      <td>0.469776</td>
      <td>-0.007274</td>
      <td>-0.165966</td>
      <td>1.000000</td>
      <td>-0.122312</td>
    </tr>
    <tr>
      <th>label2</th>
      <td>0.034911</td>
      <td>0.035865</td>
      <td>0.024568</td>
      <td>-0.129263</td>
      <td>0.052322</td>
      <td>0.015032</td>
      <td>0.019767</td>
      <td>0.040407</td>
      <td>-0.303851</td>
      <td>-0.294259</td>
      <td>-0.003406</td>
      <td>0.148583</td>
      <td>-0.122312</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#correlation heatmap matrix
plt.figure(figsize=(10,5))
sns.heatmap(df.select_dtypes(include=[np.number]).corr(method='pearson'), vmin=-1, vmax=1, annot=True,cmap='coolwarm')
plt.title('Correlation heatmap indicates many low correlated variables',
fontsize=12)
plt.show();
```


    
![png](output_32_0.png)
    


It can be seen from the heatmap that session and drives are highly correlated; 1.0 followed by driving_days and activity_days: 0.9


```python
 #  new device2 variable, where android is 0 and iphone is 1
df['device2'] = np.where(df['device']=='Android', 0, 1)
df[['device', 'device2']].head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>device</th>
      <th>device2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Android</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>iPhone</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Android</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>iPhone</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Android</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# detach predictor variables
X = df.drop(columns = ['label', 'label2', 'device', 'sessions', 'driving_days'])

```


```python
 # detach target variable
y = df['label2']

```


```python
#Perform the train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y,random_state=42)
```


```python
 # Use .head()
X_train.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>drives</th>
      <th>total_sessions</th>
      <th>n_days_after_onboarding</th>
      <th>total_navigations_fav1</th>
      <th>total_navigations_fav2</th>
      <th>driven_km_drives</th>
      <th>duration_minutes_drives</th>
      <th>activity_days</th>
      <th>device_type</th>
      <th>km_per_driving_day</th>
      <th>professional_driver</th>
      <th>device2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>152</th>
      <td>108</td>
      <td>186.192746</td>
      <td>3116</td>
      <td>243</td>
      <td>124</td>
      <td>8898.716275</td>
      <td>4668.180092</td>
      <td>24</td>
      <td>1</td>
      <td>612.305861</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11899</th>
      <td>2</td>
      <td>3.487590</td>
      <td>794</td>
      <td>114</td>
      <td>18</td>
      <td>3286.545691</td>
      <td>1780.902733</td>
      <td>5</td>
      <td>1</td>
      <td>3286.545691</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10937</th>
      <td>139</td>
      <td>347.106403</td>
      <td>331</td>
      <td>4</td>
      <td>7</td>
      <td>7400.838975</td>
      <td>2349.305267</td>
      <td>15</td>
      <td>2</td>
      <td>616.736581</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>669</th>
      <td>108</td>
      <td>455.439492</td>
      <td>2320</td>
      <td>11</td>
      <td>4</td>
      <td>6566.424830</td>
      <td>4558.459870</td>
      <td>18</td>
      <td>1</td>
      <td>410.401552</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8406</th>
      <td>10</td>
      <td>89.475821</td>
      <td>2478</td>
      <td>135</td>
      <td>0</td>
      <td>1271.248661</td>
      <td>938.711572</td>
      <td>27</td>
      <td>1</td>
      <td>74.779333</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
model = LogisticRegression(penalty='none', max_iter=400)
model.fit(X_train, y_train)

```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(max_iter=400, penalty=&#x27;none&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(max_iter=400, penalty=&#x27;none&#x27;)</pre></div></div></div></div></div>




```python
pd.Series(model.coef_[0], index=X.columns)

```




    drives                     0.001907
    total_sessions             0.000331
    n_days_after_onboarding   -0.000406
    total_navigations_fav1     0.001236
    total_navigations_fav2     0.000939
    driven_km_drives          -0.000015
    duration_minutes_drives    0.000109
    activity_days             -0.106000
    device_type               -0.002370
    km_per_driving_day         0.000018
    professional_driver       -0.001528
    device2                   -0.001041
    dtype: float64




```python
model.intercept_

```




    array([-0.00170583])




```python
# Get the predicted probabilities of the training data
training_probabilities = model.predict_proba(X_train)
training_probabilities
```




    array([[0.93942428, 0.06057572],
           [0.61980557, 0.38019443],
           [0.76498069, 0.23501931],
           ...,
           [0.91905269, 0.08094731],
           [0.85069248, 0.14930752],
           [0.93506315, 0.06493685]])




```python
 #  Copy the X_train dataframe and assign to logit_data
logit_data = X_train.copy()

#  Create a new logit column in the `logit_data` df
logit_data['logit'] = [np.log(prob[1] / prob[0]) for prob in training_probabilities]

```


```python
# Plot regplot of activity_days log-odds
sns.regplot(x='activity_days', y='logit', data=logit_data, scatter_kws={'s': 2,'alpha': 0.5})
plt.title('Log-odds: activity_days');
```


    
![png](output_44_0.png)
    



```python
 # Generate predictions on X_test
y_preds = model.predict(X_test)

```


```python
# Score the model (accuracy) on the test data
model.score(X_test, y_test)

```




    0.8237762237762237




```python
 cm = confusion_matrix(y_test, y_preds)

```


```python
 disp = ConfusionMatrixDisplay(confusion_matrix=cm,
display_labels=['retained', 'churned'],
)
disp.plot();

```


    
![png](output_48_0.png)
    



```python
 # Calculate precision manually
precision = cm[1,1] / (cm[0, 1] + cm[1, 1])
precision

```




    0.5178571428571429




```python
 # Calculate recall manually
recall = cm[1,1] / (cm[1, 0] + cm[1, 1])
recall
```




    0.0914826498422713




```python
# Create a classification report
target_labels = ['retained', 'churned']
print(classification_report(y_test, y_preds, target_names=target_labels))

```

                  precision    recall  f1-score   support
    
        retained       0.83      0.98      0.90      2941
         churned       0.52      0.09      0.16       634
    
        accuracy                           0.82      3575
       macro avg       0.68      0.54      0.53      3575
    weighted avg       0.78      0.82      0.77      3575
    
    


```python
# Create a list of (column_name, coefficient) tuples
feature_importance = list(zip(X_train.columns, model.coef_[0]))
# Sort the list by coefficient value
feature_importance = sorted(feature_importance, key=lambda x: x[1],reverse=True)
feature_importance

```




    [('drives', 0.0019066742599176349),
     ('total_navigations_fav1', 0.001235548228526216),
     ('total_navigations_fav2', 0.0009387995799501198),
     ('total_sessions', 0.00033131328278374745),
     ('duration_minutes_drives', 0.00010916811938228228),
     ('km_per_driving_day', 1.8215574939099497e-05),
     ('driven_km_drives', -1.4672270666978162e-05),
     ('n_days_after_onboarding', -0.00040603094503487565),
     ('device2', -0.0010414875971654172),
     ('professional_driver', -0.0015281656832739944),
     ('device_type', -0.0023701774762079513),
     ('activity_days', -0.10599995248350358)]




```python
#Plot the feature importances
import seaborn as sns
sns.barplot(x=[x[1] for x in feature_importance],
y=[x[0] for x in feature_importance],
orient='h')
plt.title('Feature importance');
```


    
![png](output_53_0.png)
    


### Conclusion

It can be seen that activity_days was by far the most important feature in the model. It had a negative correlation with user churn. This was not surprising, as this variable was very strongly correlated with driving_days, which was known from EDA to have a negative correlation with churn.Also user churn rate increased as the values in km_per_driving_day increased. The correlation heatmap revealed this variable to have the strongest positive correlation with churn of any of the predictor variables by a relatively large margin. In the model, it was the second-least-important variable. The model is not a strong enough predictor, as made clear by its poor recall score. However, if the model is only being used to guide further exploratory efforts, then it can have value.


```python

```
